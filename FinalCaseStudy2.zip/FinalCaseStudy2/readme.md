Case Study 2 - EV Carbon Emission Analysis <br>

1. Data Extraction: Through Copy Data Activity in Azure Data Factory. 
2. Data Transformation: Through Azure DataBricks.
3. Data Load: Though Power BI. <br>
   
Team Members: <br>
1. Juhi Shaw
2. Kriti Vaid
3. Anushka Patel
4. Athena George
5. Ohm Omar
